#!/usr/bin/env python
#
# Created on Sat Apr 20 22:16:10 IST 2019
# Purpose :: Launcher for SeedCalculator
#
import sys
import time
import math
import getpass,socket
import InputData
#

version="1.0.0"
prog="SeedGerminator"
	
def opt_parser():
	if len(sys.argv) != 2 :
		usage()
		exit ()
	else:
		fname = sys.argv[1]
		return fname
		
def usage():
	print "Usage: SeedGerminator inputfile"
	print "\nVersion :: 1.0.0"
	print "Report bugs to <rajeshprasanth@rediffmail.com>"
	
def ReadInputFile(filename = str):
	try:
    		ifile = open(filename, 'r')
	except IOError:
		print "--------------------------------------------------------------"
		print "Fatal Error :: ",filename," is not found !!"
		print "Resolution  :: Check for the ",filename," in current directory"
		print "--------------------------------------------------------------"
		sys.exit()
	#-----------------------------------------------------------------
	# Setting default values for some keywords
	#-----------------------------------------------------------------
	model = '4-hill'
	AUC_lower_limit = 0
	AUC_upper_limit = 0
	title = 'system'
	with ifile:
    		for line in ifile:
    			li=line.strip()
    			if not li.startswith("#"):
	    			if "title" in line:
	    				title = str(line.split(":")[1].strip())
	    			if "maxseeds" in line:
					maxseeds = int(line.split(":")[1].strip())
				if "model" in line:
					model = str(line.split(":")[1].strip())
				if "AUC_lower_limit" in line:
					AUC_lower_limit = float(line.split(":")[1].strip())
				if "AUC_upper_limit" in line:
					AUC_upper_limit = float(line.split(":")[1].strip())
				if "fname_uniformity" in line:
					fname_uniformity = str(line.split(":")[1].strip())
				if "fname_generic_t_calc" in line:
					fname_generic_t_calc = str(line.split(":")[1].strip())
				if "fname_germination_data" in line:
					fname_germination_data = str(line.split(":")[1].strip())
	#--------------------------------------------------------------------
	# Open germination datafile
	#--------------------------------------------------------------------
	germination_data_x, germination_data_y = [], []
	uniformity_data_x, uniformity_data_y = [], []
	generic_t_data = []
		
	try:
    		ifile = open(fname_germination_data, 'r')
	except IOError:
    		print " --------------------------------------------------------------"
		print " Fatal Error :: ",fname_germination_data,"is not found !!"
		print " Resolution  :: Check for the ",fname_germination_data," in current directory"
		print " --------------------------------------------------------------"
		sys.exit()
	with ifile:
    		for line in ifile:
    			li=line.strip()
    			if not li.startswith("#"):
		    		values = [float(s) for s in line.strip().split()]
		    		germination_data_x.append(values[0])
  				germination_data_y.append(values[1])
  	#--------------------------------------------------------------------
	# Open fname_generic_t_calc datafile
	#--------------------------------------------------------------------
	
        try:
    		ifile = open(fname_generic_t_calc, 'r')
	except IOError:
    		print " --------------------------------------------------------------"
		print " Fatal Error :: ",fname_generic_t_calc,"is not found !!"
		print " Resolution  :: Check for the ",fname_generic_t_calc," in current directory"
		print " --------------------------------------------------------------"
		sys.exit()
	with ifile:
    		for line in ifile:
    			li=line.strip()
    			if not li.startswith("#"):
		    		values = [float(s) for s in line.strip().split()]
		    		generic_t_data.append(values[0])
        #--------------------------------------------------------------------
	# Open fname_uniformity datafile
	#--------------------------------------------------------------------
		
	try:
    		ifile = open(fname_uniformity, 'r')
	except IOError:
    		print " --------------------------------------------------------------"
		print " Fatal Error :: ",fname_uniformity,"is not found !!"
		print " Resolution  :: Check for the ",fname_uniformity," in current directory"
		print " --------------------------------------------------------------"
		sys.exit()
	with ifile:
    		for line in ifile:
    			li=line.strip()
    			if not li.startswith("#"):
		    		values = [float(s) for s in line.strip().split()]
		    		uniformity_data_x.append(values[0])
  				uniformity_data_y.append(values[1])
  	#--------------------------------------------------------------------
	# some default values, if nothing read from input file
	#--------------------------------------------------------------------
	if AUC_upper_limit < 0:
		AUC_upper_limit = max(germination_data_x)
	
	#--------------------------------------------------------------------
	# creating inpdata object
	#--------------------------------------------------------------------
	
	inpdata = InputData.InputData(filename,title,maxseeds,model, AUC_lower_limit, AUC_upper_limit, fname_uniformity, fname_generic_t_calc, fname_germination_data, germination_data_x, germination_data_y,  uniformity_data_x, uniformity_data_y, generic_t_data)
  	
  	return inpdata
  	
def inputcheck(data):
	#----------------------------------------------------------------------
	# Check for maxseeds
	#----------------------------------------------------------------------
	if data.maxseeds <= 0:
		print " --------------------------------------------------------------"
		print " Fatal Error :: maxseeds <= 0"
		print " Resolution  :: Choose maxseeds > 0"
		print " --------------------------------------------------------------"
		exit()
	#----------------------------------------------------------------------
	# Check for fitting model
	#----------------------------------------------------------------------
	std_model = [ '3-hill', '4-hill', '4-logistic', '5-logistic', 'all']
	if data.model.strip() not in std_model:
		print " --------------------------------------------------------------"
		print " Fatal Error :: ",data.model,"is not supported. May be incorrect keyword"
		print " Resolution  :: Supported keywords - 4-hill/5-hill/logistic"
		print " --------------------------------------------------------------"
		exit()
		
	#----------------------------------------------------------------------
	# Check for AUC limits
	#----------------------------------------------------------------------
	if data.AUC_lower_limit > data.AUC_upper_limit  :
		print "--------------------------------------------------------------"
		print "Fatal Error :: AUC_lower_limit > AUC_upper_limit"
		print "Resolution  :: Choose AUC_lower_limit < AUC_upper_limit"
		print "--------------------------------------------------------------"
		
		exit()
	return()

def banner(data):
	print " =-----------------------------------------------------------="
	print "\t\t\t",prog,"-V",version
	print " =-----------------------------------------------------------="
	print " \tStarted on :: ",str((time.asctime( time.localtime(time.time())))).strip()
	print " \tRun mode :: Batch"
	print " \tUsername :: ",getpass.getuser().strip()
	print " \tMachine Name :: ",socket.gethostname().strip()
	print " ............................................................."
	print "      Reading data from input file :: ",data.filename
	print " ............................................................."
	
	print " \tFit Model :: ",data.model
	print " \tMaximum # of ",data.maxseeds
