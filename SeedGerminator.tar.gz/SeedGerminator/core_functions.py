#!/usr/bin/env python
#
# Created on Mon May  6 04:08:23 IST 2019
# Purpose :: Core functions are in this file.
#
import sys
import math
import InputData
import aux_functions

def mean(data):
	return float(sum(data))/float(len(data))

def hill_3p(Vmax, k, n, x):
	Vmax = float(Vmax)
	k = float(k)
	n = float(n)
	x = float(x)
	
	num = float(Vmax) * float((x**n))
	den = float((k**n)) + float((x**n))
	
	y = float(num)/float(den)
	
	return float(y)

def hill_4p(START, END,k,n, x):
	k = float(k)
	n = float(n)
	x = float(x)
	START = float(START)
	END = float(END)
	
	num = float(END - START) * float((x**n))
	den = float((k**n)) + float((x**n))
	
	y = float(START) + float (num/den)
	
	return float(y)
	
def logistic_4p(A1, A2, x0, p):
	A1 = float(A1)
	A2 = float(A2)
	x0 = float(x0)
	p = float(p)
	
	num = float(A1 - A2)
	den = float(1 + float((x/x0)**p))
	
	y = float(num/den) + A2
	
	return float(y)
	
def logistic_5p(Amin, Amax, x0, h, s):
	Amin = float(Amin)
	Amax = float(Amax)
	x0 = float(x0)
	h = float(h)
	s = float(s)
	
	num = float(Amax - Amin)
	den = float((1 + ((x/x0)**(-h)))**s)

	y = Amin + float(num/den)
	
	return float(y)

def GerminationParameters(maxseeds,germination_data_x,germination_data_y):
	#--------------------------------------------------------------------------
	# Maximum Seed growth calculations
	#
	# Variables = maxseeds_germinated, maxseeds_growth_percentage
	#--------------------------------------------------------------------------
	maxseeds_germinated = max(germination_data_y)
	maxseeds_growth_percentage = float((100*max(germination_data_y))/maxseeds)
	#--------------------------------------------------------------------------
	# Mean germination time calculations
	#
	# Variables = mean_germination_time
	#--------------------------------------------------------------------------
	abs_germination_data_y=[]
	temp = []
	for i in range(0,len(germination_data_y)):
		abs_germination_data_y.append(germination_data_y[i])
		temp.append(germination_data_y[i])
	for i in range(1,len(germination_data_y)):
		abs_germination_data_y[i] = germination_data_y[i] - germination_data_y[i-1]
	print "--->",abs_germination_data_y
	for i in range(0,len(germination_data_y)):
		temp[i] = germination_data_x[i] * abs_germination_data_y[i]
	
	mean_germination_time = float(sum(temp)/sum(abs_germination_data_y))
	#--------------------------------------------------------------------------
	# Standard Deviation of Mean germination time calculations
	#
	# Variables = sd_mean_germination_time
	#--------------------------------------------------------------------------
	for i in range(0,len(germination_data_y)):
		temp[i] = abs_germination_data_y[i]*((germination_data_x[i]-mean_germination_time)**2)
	sd_mean_germination_time = math.sqrt(sum(temp)/(sum(abs_germination_data_y) - 1))
	#--------------------------------------------------------------------------
	# Coefficient of Variation of the Germination Time
	#
	# Variables = cv_germination_time
	#--------------------------------------------------------------------------
	cv_germination_time = (float(sd_mean_germination_time)/float(mean_germination_time))*100
	#--------------------------------------------------------------------------
	# Mean Germination Rate calculation
	#
	# Variables = mean_germination_rate
	#--------------------------------------------------------------------------
	mean_germination_rate = float(1/float(mean_germination_time))
	#--------------------------------------------------------------------------
	# Uncertainty Index (U) calculation
	#
	# Variables = unicertainity_index
	#--------------------------------------------------------------------------
	freq,temp1 = [],[]
	for i in range(0,len(abs_germination_data_y)):
		freq.append((abs_germination_data_y[i])/sum(abs_germination_data_y))
	
	#for i in range(0,len(abs_germination_data_y)):
		#temp1.append(math.log(freq[i],2))
	print freq
	t=math.log(freq[0],2)
	print t

