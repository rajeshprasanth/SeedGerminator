#!/usr/bin/env python
#
# Created on Mon May  6 03:59:54 IST 2019
# Purpose :: Definitions for SeedCalculator
#
class InputData:
	def __init__ (self, filename=str, title=str,maxseeds=int, model=str, AUC_lower_limit=float, AUC_upper_limit=float, fname_uniformity=str, fname_generic_t_calc=str, fname_germination_data=str, germination_data_x=[], germination_data_y=[],  uniformity_data_x=[], uniformity_data_y=[], generic_t_data=[]):
		self.filename = filename
		self.title = title
		self.maxseeds = maxseeds
		self.model = model
		self.AUC_lower_limit = AUC_lower_limit
		self.AUC_upper_limit = AUC_upper_limit
		self.fname_uniformity = fname_uniformity
		self.fname_generic_t_calc = fname_generic_t_calc
		self.fname_germination_data = fname_germination_data
		self.germination_data_x = germination_data_x
		self.germination_data_y = germination_data_y
		self.uniformity_data_x = uniformity_data_x
		self.uniformity_data_y = uniformity_data_y
		self.generic_t_data = generic_t_data
